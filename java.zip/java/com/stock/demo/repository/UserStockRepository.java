package com.stock.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stock.demo.entity.UserStock;

public interface UserStockRepository extends JpaRepository<UserStock,Long> {

}
