package com.stock.demo.service;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stock.demo.entity.UserStock;
import com.stock.demo.repository.UserStockRepository;

@Service
public class UserStockService {

	private final UserStockRepository userRepository;
	private final static Logger logger = LoggerFactory.getLogger(UserStockService.class);

	@Autowired
	public UserStockService(UserStockRepository userRepository) {
		this.userRepository = userRepository;
	}

	public UserStock saveTrade(UserStock userStock) {
		logger.info("saving the product informartion in UserStock Table.");
		return userRepository.save(userStock);
	}

	public Optional<UserStock> findTrade(long id) {
		logger.info("saving the product informartion in UserStock Table.");
		return userRepository.findById(id);
	}
	
	public void sellTrade(long id) {
		logger.info("saving the product informartion in UserStock Table.");
		userRepository.deleteById(id);;
	}

}
